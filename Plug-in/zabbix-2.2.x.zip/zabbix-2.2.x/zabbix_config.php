<?php 
global $zabbix_api_config;

$zabbix_api_config=array(
 'api_url'=>'api_jsonrpc.php',
 'user'=>'admin',
 'passowrd'=>'xxxxx',
 'graph_url'=>'zabbix_chart.php',
);

?>
